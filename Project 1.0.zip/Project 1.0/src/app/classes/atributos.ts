export class Contato {
    nome: string; 
    idade: number; 
    telefone: number; 
    email: string;
    localizacao: Localizacao
}

export interface Localizacao { 
    endereco: Location; 
    estado: Location;
    cep: Location; 
}